export default function AddLog() {
  return <div className="container mx-auto p-4">Add Health Log Page</div>;
}