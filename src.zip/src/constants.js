export const API_URL = "http://localhost:5000/api";

export const MOOD_OPTIONS = [
  "Good",
  "Okay",
  "Relaxed",
  "Stressed",
  "Tired",
  "Happy",
  "Sad",
];